<?php

namespace Illuminate\Database\Events;

class TransactionBeginning extends ConnectionEvent
{
    //
}
